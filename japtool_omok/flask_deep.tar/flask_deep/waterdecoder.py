import cv2
import numpy as np
import random
import matplotlib.pyplot as plt

def main(refer_img_path, target_img_path):

    img = cv2.imread(refer_img_path)
    result = cv2.imread(target_img_path)

    height, width, _ = img.shape
    result = cv2.resize(result,dsize=(width,height),interpolation=cv2.INTER_AREA)

    img_ori_f = np.fft.fft2(img)
    img_input_f = np.fft.fft2(result)

    alpha = 10
    watermark = (img_ori_f - img_input_f) / alpha
    watermark = np.real(watermark)

    y_random_indices, x_random_indices = list(range(height)), list(range(width))
    random.seed(9980)
    random.shuffle(x_random_indices)
    random.shuffle(y_random_indices)

    result2 = np.zeros(watermark.shape, dtype=np.uint8)

    for y in range(height):
        for x in range(width):
            result2[y, x] = watermark[y_random_indices[y], x_random_indices[x]]

    cv2.imwrite('rere.png',result2)

    name = str(target_img_path).split('/')[-1]
    name = name.split('.')[-2]
    
    cv2.imwrite('./flask_deep/static/img/moment/' + name + '_recover.png', result2)

    return name