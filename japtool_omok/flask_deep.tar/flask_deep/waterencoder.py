import cv2
import numpy as np
import random
import matplotlib.pyplot as plt

def main(refer_img_path, target_img_path):

    img = cv2.imread(refer_img_path)
    img_wm = cv2.imread(target_img_path)


    height, width, _ = img.shape
    wm_height, wm_width, _ = img_wm.shape

    img_f = np.fft.fft2(img)

    y_random_indices, x_random_indices = list(range(height)), list(range(width))
    random.seed(9980)
    random.shuffle(x_random_indices)
    random.shuffle(y_random_indices)

    random_wm = np.zeros(img.shape, dtype=np.uint8)

    for y in range(wm_height):
        for x in range(wm_width):
            random_wm[y_random_indices[y], x_random_indices[x]] = img_wm[y, x]

    alpha = 10

    result_f = img_f + alpha * random_wm

    result = np.fft.ifft2(result_f)
    result = np.real(result)
    # result = result.astype(np.uint8)
    
    
    name = str(refer_img_path).split('/')[-1]
    name = name.split('.')[-2]
    
    cv2.imwrite('./flask_deep/static/img/moment/' + name + '_change.png', result)

    return name


